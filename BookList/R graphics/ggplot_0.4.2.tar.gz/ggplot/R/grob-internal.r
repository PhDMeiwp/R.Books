# Grob creation functons
# 
# See \code{vignette("writing-grob-functions")} for more details.
# 
# @keyword internal 
# @alias grob_2density
# @alias grob_abline
# @alias grob_area
# @alias grob_bar
# @alias grob_boxplot
# @alias grob_contour
# @alias grob_density
# @alias grob_group
# @alias grob_errorbar
# @alias grob_histogram
# @alias grob_hline
# @alias grob_jitter
# @alias grob_line
# @alias grob_path
# @alias grob_point
# @alias grob_polygon
# @alias grob_quantile
# @alias grob_rect
# @alias grob_ribbon
# @alias grob_smooth
# @alias grob_text
# @alias grob_tile
# @alias grob_vline
# @alias pre_bar
# @alias pre_density
# @alias pre_errorbar
# @alias pre_group
# @alias pre_histogram
# @alias pre_ribbon

grob_XXX <- function() {}