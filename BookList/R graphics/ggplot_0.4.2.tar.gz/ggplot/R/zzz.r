.onLoad <- function(libname, pkgname) {
	packageStartupMessage("ggplot is now deprecated.  Please visit http://had.co.nz/ggplot2 to learn more about the latest version")
	TRUE
}
